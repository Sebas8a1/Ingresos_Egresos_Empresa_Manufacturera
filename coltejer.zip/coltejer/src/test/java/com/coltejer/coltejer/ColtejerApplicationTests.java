package com.coltejer.coltejer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColtejerApplicationTests {

	@Test
	void contextLoads() {
	}

}
